rm -rf bin
rm -rf gen
rm -rf obj
rm -rf libs
